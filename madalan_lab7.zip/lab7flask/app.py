import os
import sqlite3
from flask import Flask,request,g,redirect,url_for,render_template,flash,session


app = Flask(__name__)
app.config.from_object(__name__)

app.config.update(dict(
   DATABASE=os.path.join(app.root_path,'users.db'),
   DEBUG=True,
   SECRET_KEY='admin',
   USERNAME='admin',
   PASSWORD='default'
))
app.config.from_envvar('FLASKR_SETTINGS',silent=True)

def checkSmall(s):
  for char in s:
    k = char.islower() 
    if k == True:
        return True
  return False
def checkCaptial(s):
  for char in s:
    k = char.isupper() 
    if k == True:
        return True
  return False
def checkNumber(s):
  return s[-1].isdigit()
def connect_db():
  rv=sqlite3.connect(app.config['DATABASE'])
  rv.row_factory=sqlite3.Row
  return rv

def get_db():
  if not hasattr(g,'sqlite_db'):
     g.sqlite_db=connect_db()
  return g.sqlite_db


count=0
@app.route('/add',methods=['GET','POST'])
def add():
  global count
  show_results=0
  entries=[]
  if request.method=='POST':
    
    if request.form['add']=="add":
      s=request.form['password']
      u=request.form['userid']
      if(checkSmall(s) and checkCaptial(s) and checkNumber(s) and len(s)>7 ):
        db=get_db()
        db.execute('insert into users(username,password) values(?,?)',(request.form['userid'],request.form['password'],))
        db.commit()
        #flash(' Details added')
        show_results=1
      else:
        count+=1
        print(count)
        if(count>2):
          flash("You have Tried more than 3 times")
        show_results=0
        if(not checkSmall(s)):
          entries.append("You did not use an lowercase character")
        if(not checkCaptial(s)):
          entries.append("You did not use an uppercase character")
        if(not checkNumber(s)):
          entries.append("You did not end your password with a number")
        if(len(s)<8):
          entries.append("password should be at least 8 characters")
          
          
        
        
  return render_template('report.html',show_results=show_results,entries=entries)

@app.route('/',methods=['GET','POST'])
def home():
   return render_template('home.html')


@app.teardown_appcontext
def close_db(error):
  if hasattr(g,'sqlite_db'):
     g.sqlite_db.close()



if __name__=='__main__':
 app.run(debug=True)
