import sqlite3

#Connecting to sqlite
conn = sqlite3.connect('users.db')

#Creating a cursor object using the cursor() method
cursor = conn.cursor()

#Doping EMPLOYEE table if already exists.
cursor.execute("DROP TABLE IF EXISTS users")

#Creating table as per requirement
sql ='''CREATE TABLE users(
   userid integer primary key AUTOINCREMENT,
   username CHAR(120) NOT NULL,
   password CHAR(120) NOT NULL
)'''
cursor.execute(sql)
print("Table created successfully........")

# Commit your changes in the database
conn.commit()

#Closing the connection
conn.close()
